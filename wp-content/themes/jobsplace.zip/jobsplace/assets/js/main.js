( function( $ ){
	$(document).ready(function(){
					
	});
	
} ( jQuery ) );
function popitup(url) {
		newwindow=window.open(url,"name","height=380,width=480");
		if (window.focus) {newwindow.focus()}
		return false;
	}