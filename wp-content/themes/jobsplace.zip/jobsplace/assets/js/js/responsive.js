$(window).resize(function(){	
	if ($("body").css("padding") == "10px" ){
		// your code here
		$("#skin-select #toggle.active").css({"display":"none"});

	}
});