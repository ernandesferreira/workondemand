<?php get_header(); ?>
<div class='container'>
	<div class='row'>
		<div class='col-lg-12'>

		</div>
	</div>
</div>
<?php get_footer(); ?>